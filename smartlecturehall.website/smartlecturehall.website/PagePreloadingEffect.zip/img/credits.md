Vintage logo template from [GraphicBurger](http://graphicburger.com/6-vintage-logo-templates/) by [Nicky Laatz](https://creativemarket.com/Nickylaatz?u=raul.taciu)
